from __builtin__ import object as _object
from __builtin__ import property as _swig_property


if False:
    from typing import Dict, List, Tuple, Union, Optional

class MDynSweptTriangle(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def area(self, *args): pass
    def normal(self, *args): pass
    def normalToPoint(self, *args): pass
    def uvPoint(self, *args): pass
    def vertex(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


from . import OpenMaya

class MFnFluid(OpenMaya.MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create2D(self, *args): pass
    def create3D(self, *args): pass
    def density(self, *args): pass
    def emitIntoArrays(self, *args): pass
    def expandToInclude(self, *args): pass
    def falloff(self, *args): pass
    def fuel(self, *args): pass
    def getColorMode(self, *args): pass
    def getColors(self, *args): pass
    def getCoordinateMode(self, *args): pass
    def getCoordinates(self, *args): pass
    def getDensityMode(self, *args): pass
    def getDimensions(self, *args): pass
    def getFalloffMode(self, *args): pass
    def getForceAtPoint(self, *args): pass
    def getFuelMode(self, *args): pass
    def getResolution(self, *args): pass
    def getTemperatureMode(self, *args): pass
    def getVelocity(self, *args): pass
    def getVelocityMode(self, *args): pass
    def gridSize(self, *args): pass
    def index(self, *args): pass
    def isAutoResize(self, *args): pass
    def isResizeToEmitter(self, *args): pass
    def pressure(self, *args): pass
    def setColorMode(self, *args): pass
    def setCoordinateMode(self, *args): pass
    def setDensityMode(self, *args): pass
    def setFalloffMode(self, *args): pass
    def setFuelMode(self, *args): pass
    def setSize(self, *args): pass
    def setTemperatureMode(self, *args): pass
    def setVelocityMode(self, *args): pass
    def temperature(self, *args): pass
    def toGridIndex(self, *args): pass
    def type(self, *args): pass
    def updateGrid(self, *args): pass
    def velocityGridSizes(self, *args): pass
    def voxelCenterPosition(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kCenterGradient = 7
    
    
    kConstant = 0
    
    
    kDynamicColorGrid = 2
    
    
    kDynamicGrid = 2
    
    
    kFixed = 0
    
    
    kGradient = 3
    
    
    kGrid = 1
    
    
    kNegXGradient = 4
    
    
    kNegYGradient = 5
    
    
    kNegZGradient = 6
    
    
    kNoFalloffGrid = 0
    
    
    kStaticColorGrid = 1
    
    
    kStaticFalloffGrid = 1
    
    
    kStaticGrid = 1
    
    
    kUseShadingColor = 0
    
    
    kXGradient = 1
    
    
    kYGradient = 2
    
    
    kZGradient = 3
    
    
    kZero = 0


class floatPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MnObject(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFnParticleSystem(OpenMaya.MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def acceleration(self, *args): pass
    def age(self, *args): pass
    def betterIllum(self, *args): pass
    def castsShadows(self, *args): pass
    def count(self, *args): pass
    def create(self, *args): pass
    def deformedParticleShape(self, *args): pass
    def disableCloudAxis(self, *args): pass
    def emission(self, *args): pass
    def emit(self, *args): pass
    def evaluateDynamics(self, *args): pass
    def flatShaded(self, *args): pass
    def getPerParticleAttribute(self, *args): pass
    def hasEmission(self, *args): pass
    def hasLifespan(self, *args): pass
    def hasOpacity(self, *args): pass
    def hasRgb(self, *args): pass
    def isDeformedParticleShape(self, *args): pass
    def isPerParticleDoubleAttribute(self, *args): pass
    def isPerParticleIntAttribute(self, *args): pass
    def isPerParticleVectorAttribute(self, *args): pass
    def isValid(self, *args): pass
    def lifespan(self, *args): pass
    def mass(self, *args): pass
    def opacity(self, *args): pass
    def originalParticleShape(self, *args): pass
    def particleIds(self, *args): pass
    def particleName(self, *args): pass
    def position(self, *args): pass
    def position0(self, *args): pass
    def position1(self, *args): pass
    def primaryVisibility(self, *args): pass
    def radius(self, *args): pass
    def radius0(self, *args): pass
    def radius1(self, *args): pass
    def receiveShadows(self, *args): pass
    def renderType(self, *args): pass
    def rgb(self, *args): pass
    def saveInitialState(self, *args): pass
    def setCount(self, *args): pass
    def setPerParticleAttribute(self, *args): pass
    def surfaceShading(self, *args): pass
    def tailSize(self, *args): pass
    def threshold(self, *args): pass
    def type(self, *args): pass
    def velocity(self, *args): pass
    def visibleInReflections(self, *args): pass
    def visibleInRefractions(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kBlobby = 2
    
    
    kCloud = 0
    
    
    kMultiPoint = 3
    
    
    kMultiStreak = 4
    
    
    kNumeric = 5
    
    
    kPoints = 6
    
    
    kSpheres = 7
    
    
    kSprites = 8
    
    
    kStreak = 9
    
    
    kTube = 1


class doublePtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFnDynSweptGeometryData(OpenMaya.MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def lineCount(self, *args): pass
    def sweptLine(self, *args): pass
    def sweptTriangle(self, *args): pass
    def triangleCount(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class uIntPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MDynamicsUtil(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addNodeTypeToRunup(*args, **kwargs): pass
    @staticmethod
    def evalDynamics2dTexture(*args, **kwargs): pass
    @staticmethod
    def hasValidDynamics2dTexture(*args, **kwargs): pass
    @staticmethod
    def inRunup(*args, **kwargs): pass
    @staticmethod
    def removeNodeTypeFromRunup(*args, **kwargs): pass
    @staticmethod
    def runupIfRequired(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class boolPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFnPfxGeometry(OpenMaya.MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def getBoundingBox(self, *args): pass
    def getLineData(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnField(OpenMaya.MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def attenuation(self, *args): pass
    def falloffCurve(self, *args): pass
    def getForceAtPoint(self, *args): pass
    def isFalloffCurveConstantOne(self, *args): pass
    def magnitude(self, *args): pass
    def maxDistance(self, *args): pass
    def perVertex(self, *args): pass
    def setAttenuation(self, *args): pass
    def setMagnitude(self, *args): pass
    def setMaxDistance(self, *args): pass
    def setPerVertex(self, *args): pass
    def setUseMaxDistance(self, *args): pass
    def type(self, *args): pass
    def useMaxDistance(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MDynSweptLine(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def length(self, *args): pass
    def normal(self, *args): pass
    def tangent(self, *args): pass
    def vertex(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class intPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class shortPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MRenderLine(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def getColor(self, *args): pass
    def getFlatness(self, *args): pass
    def getIncandescence(self, *args): pass
    def getLine(self, *args): pass
    def getParameter(self, *args): pass
    def getTransparency(self, *args): pass
    def getTwist(self, *args): pass
    def getWidth(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFnNIdData(OpenMaya.MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def getObjectPtr(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnNObjectData(OpenMaya.MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def getClothObjectPtr(self, *args): pass
    def getCollide(self, *args): pass
    def getParticleObjectPtr(self, *args): pass
    def getRigidObjectPtr(self, *args): pass
    def isCached(self, *args): pass
    def setCached(self, *args): pass
    def setObjectPtr(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class uCharPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MnSolver(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addNObject(self, *args): pass
    def createNSolver(self, *args): pass
    def makeAllCollide(self, *args): pass
    def removeAllCollisions(self, *args): pass
    def removeNObject(self, *args): pass
    def setAirDensity(self, *args): pass
    def setDisabled(self, *args): pass
    def setGravity(self, *args): pass
    def setGravityDir(self, *args): pass
    def setMaxIterations(self, *args): pass
    def setStartTime(self, *args): pass
    def setSubsteps(self, *args): pass
    def setWindDir(self, *args): pass
    def setWindNoiseIntensity(self, *args): pass
    def setWindSpeed(self, *args): pass
    def solve(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFnInstancer(OpenMaya.MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def allInstances(self, *args): pass
    def instancesForParticle(self, *args): pass
    def particleCount(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MRenderLineArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def deleteArray(self, *args): pass
    def length(self, *args): pass
    def renderLine(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class charPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MHairSystem(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def getCollisionObject(*args, **kwargs): pass
    @staticmethod
    def getFollicle(*args, **kwargs): pass
    @staticmethod
    def registerCollisionSolverCollide(*args, **kwargs): pass
    @staticmethod
    def registerCollisionSolverPreFrame(*args, **kwargs): pass
    @staticmethod
    def registeringCallableScript(*args, **kwargs): pass
    @staticmethod
    def setRegisteringCallableScript(*args, **kwargs): pass
    @staticmethod
    def unregisterCollisionSolverCollide(*args, **kwargs): pass
    @staticmethod
    def unregisterCollisionSolverPreFrame(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MnParticle(MnObject):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def createNParticle(self, *args): pass
    def getBounce(self, *args): pass
    def getFriction(self, *args): pass
    def getInverseMass(self, *args): pass
    def getNumVertices(self, *args): pass
    def getPositions(self, *args): pass
    def getThickness(self, *args): pass
    def getVelocities(self, *args): pass
    def setBounce(self, *args): pass
    def setCollide(self, *args): pass
    def setDamping(self, *args): pass
    def setDisableGravity(self, *args): pass
    def setDragAndLift(self, *args): pass
    def setFriction(self, *args): pass
    def setIncompressibility(self, *args): pass
    def setInverseMass(self, *args): pass
    def setLiquidRadiusScale(self, *args): pass
    def setLiquidSimulation(self, *args): pass
    def setMaxIterations(self, *args): pass
    def setMaxSelfCollisionIterations(self, *args): pass
    def setPositions(self, *args): pass
    def setRestDensity(self, *args): pass
    def setSelfCollide(self, *args): pass
    def setSelfCollideWidth(self, *args): pass
    def setSelfCollisionSoftness(self, *args): pass
    def setSurfaceTension(self, *args): pass
    def setThickness(self, *args): pass
    def setTopology(self, *args): pass
    def setVelocities(self, *args): pass
    def setViscosity(self, *args): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnNewtonField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def minDistance(self, *args): pass
    def setMinDistance(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnTurbulenceField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def frequency(self, *args): pass
    def phase(self, *args): pass
    def setFrequency(self, *args): pass
    def setPhase(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnVolumeAxisField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def detailTurbulence(self, *args): pass
    def direction(self, *args): pass
    def directionalSpeed(self, *args): pass
    def invertAttenuation(self, *args): pass
    def setDirection(self, *args): pass
    def setDirectionalSpeed(self, *args): pass
    def setInvertAttenuation(self, *args): pass
    def setSpeedAlongAxis(self, *args): pass
    def setSpeedAroundAxis(self, *args): pass
    def setSpeedAwayFromAxis(self, *args): pass
    def setSpeedAwayFromCenter(self, *args): pass
    def setTurbulence(self, *args): pass
    def setTurbulenceFrequency(self, *args): pass
    def setTurbulenceOffset(self, *args): pass
    def setTurbulenceSpeed(self, *args): pass
    def speedAlongAxis(self, *args): pass
    def speedAroundAxis(self, *args): pass
    def speedAwayFromAxis(self, *args): pass
    def speedAwayFromCenter(self, *args): pass
    def turbulence(self, *args): pass
    def turbulenceFrequency(self, *args): pass
    def turbulenceOffset(self, *args): pass
    def turbulenceSpeed(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnDragField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def direction(self, *args): pass
    def setDirection(self, *args): pass
    def setUseDirection(self, *args): pass
    def type(self, *args): pass
    def useDirection(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnUniformField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def direction(self, *args): pass
    def setDirection(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnGravityField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def direction(self, *args): pass
    def setDirection(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MnCloth(MnObject):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def createNCloth(self, *args): pass
    def getBounce(self, *args): pass
    def getFriction(self, *args): pass
    def getInverseMass(self, *args): pass
    def getNumVertices(self, *args): pass
    def getPositions(self, *args): pass
    def getThickness(self, *args): pass
    def getVelocities(self, *args): pass
    def setAddCrossLinks(self, *args): pass
    def setAirTightness(self, *args): pass
    def setBendAngleDropoff(self, *args): pass
    def setBendAngleScale(self, *args): pass
    def setBendResistance(self, *args): pass
    def setBendRestAngleFromPositions(self, *args): pass
    def setBounce(self, *args): pass
    def setCollisionFlags(self, *args): pass
    def setComputeRestAngles(self, *args): pass
    def setComputeRestLength(self, *args): pass
    def setDamping(self, *args): pass
    def setDisableGravity(self, *args): pass
    def setDragAndLift(self, *args): pass
    def setFriction(self, *args): pass
    def setIncompressibility(self, *args): pass
    def setInputMeshAttractAndRigidStrength(self, *args): pass
    def setInputMeshAttractDamping(self, *args): pass
    def setInputMeshAttractPositions(self, *args): pass
    def setInverseMass(self, *args): pass
    def setLinksRestLengthFromPositions(self, *args): pass
    def setMaxIterations(self, *args): pass
    def setMaxSelfCollisionIterations(self, *args): pass
    def setPositions(self, *args): pass
    def setPressure(self, *args): pass
    def setPressureDamping(self, *args): pass
    def setPumpRate(self, *args): pass
    def setRestitutionAngle(self, *args): pass
    def setRestitutionTension(self, *args): pass
    def setSealHoles(self, *args): pass
    def setSelfCollideWidth(self, *args): pass
    def setSelfCollisionFlags(self, *args): pass
    def setSelfCollisionSoftness(self, *args): pass
    def setSelfCrossoverPush(self, *args): pass
    def setSelfTrappedCheck(self, *args): pass
    def setShearResistance(self, *args): pass
    def setStartPressure(self, *args): pass
    def setStretchAndCompressionResistance(self, *args): pass
    def setTangentialDrag(self, *args): pass
    def setThickness(self, *args): pass
    def setTopology(self, *args): pass
    def setTrackVolume(self, *args): pass
    def setVelocities(self, *args): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnRadialField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def radialType(self, *args): pass
    def setType(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MnRigid(MnObject):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def createNRigid(self, *args): pass
    def getBounce(self, *args): pass
    def getFriction(self, *args): pass
    def getInverseMass(self, *args): pass
    def getNumVertices(self, *args): pass
    def getPositions(self, *args): pass
    def getThickness(self, *args): pass
    def getVelocities(self, *args): pass
    def setBounce(self, *args): pass
    def setCollisionFlags(self, *args): pass
    def setFriction(self, *args): pass
    def setPositions(self, *args): pass
    def setThickness(self, *args): pass
    def setTopology(self, *args): pass
    def setVelocities(self, *args): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnAirField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def componentOnly(self, *args): pass
    def direction(self, *args): pass
    def enableSpread(self, *args): pass
    def inheritRotation(self, *args): pass
    def inheritVelocity(self, *args): pass
    def setComponentOnly(self, *args): pass
    def setDirection(self, *args): pass
    def setEnableSpread(self, *args): pass
    def setInheritRotation(self, *args): pass
    def setInheritVelocity(self, *args): pass
    def setSpeed(self, *args): pass
    def setSpread(self, *args): pass
    def speed(self, *args): pass
    def spread(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnVortexField(MFnField):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def axis(self, *args): pass
    def setAxis(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}




def boolPtr_frompointer(*args, **kwargs): pass
def MFnAirField_className(*args, **kwargs): pass
def uIntPtr_swigregister(*args, **kwargs): pass
def MFnUniformField_swigregister(*args, **kwargs): pass
def MDynamicsUtil_hasValidDynamics2dTexture(*args, **kwargs): pass
def MDynamicsUtil_addNodeTypeToRunup(*args, **kwargs): pass
def MnParticle_swigregister(*args, **kwargs): pass
def MDynamicsUtil_swigregister(*args, **kwargs): pass
def floatPtr_swigregister(*args, **kwargs): pass
def MDynSweptLine_className(*args, **kwargs): pass
def MFnNObjectData_swigregister(*args, **kwargs): pass
def MHairSystem_registeringCallableScript(*args, **kwargs): pass
def MFnVortexField_className(*args, **kwargs): pass
def MFnVortexField_swigregister(*args, **kwargs): pass
def MHairSystem_unregisterCollisionSolverPreFrame(*args, **kwargs): pass
def MnCloth_swigregister(*args, **kwargs): pass
def MRenderLineArray_className(*args, **kwargs): pass
def MHairSystem_swigregister(*args, **kwargs): pass
def _swig_repr(self): pass
def MFnTurbulenceField_className(*args, **kwargs): pass
def uIntPtr_frompointer(*args, **kwargs): pass
def _swig_setattr_nondynamic(self, class_type, name, value, static='1'): pass
def MFnField_swigregister(*args, **kwargs): pass
def MFnVolumeAxisField_className(*args, **kwargs): pass
def MFnDynSweptGeometryData_swigregister(*args, **kwargs): pass
def MFnGravityField_className(*args, **kwargs): pass
def MDynamicsUtil_runupIfRequired(*args, **kwargs): pass
def MFnGravityField_swigregister(*args, **kwargs): pass
def MFnDragField_swigregister(*args, **kwargs): pass
def MFnFluid_swigregister(*args, **kwargs): pass
def MFnInstancer_swigregister(*args, **kwargs): pass
def MFnNIdData_className(*args, **kwargs): pass
def MDynamicsUtil_inRunup(*args, **kwargs): pass
def MFnNIdData_swigregister(*args, **kwargs): pass
def MnRigid_swigregister(*args, **kwargs): pass
def MFnParticleSystem_swigregister(*args, **kwargs): pass
def floatPtr_frompointer(*args, **kwargs): pass
def MHairSystem_unregisterCollisionSolverCollide(*args, **kwargs): pass
def MFnNewtonField_className(*args, **kwargs): pass
def MHairSystem_setRegisteringCallableScript(*args, **kwargs): pass
def MFnNewtonField_swigregister(*args, **kwargs): pass
def charPtr_swigregister(*args, **kwargs): pass
def MnObject_swigregister(*args, **kwargs): pass
def doublePtr_swigregister(*args, **kwargs): pass
def uCharPtr_frompointer(*args, **kwargs): pass
def _swig_getattr(self, class_type, name): pass
def MFnAirField_swigregister(*args, **kwargs): pass
def MRenderLine_swigregister(*args, **kwargs): pass
def charPtr_frompointer(*args, **kwargs): pass
def MFnInstancer_className(*args, **kwargs): pass
def weakref_proxy(*args, **kwargs):
    """
    proxy(object[, callback]) -- create a proxy object that weakly
    references 'object'.  'callback', if given, is called with a
    reference to the proxy when 'object' is about to be finalized.
    """
    pass
def MFnDynSweptGeometryData_className(*args, **kwargs): pass
def MHairSystem_className(*args, **kwargs): pass
def MRenderLineArray_swigregister(*args, **kwargs): pass
def intPtr_swigregister(*args, **kwargs): pass
def MFnNObjectData_className(*args, **kwargs): pass
def uCharPtr_swigregister(*args, **kwargs): pass
def MDynSweptTriangle_swigregister(*args, **kwargs): pass
def MFnPfxGeometry_className(*args, **kwargs): pass
def MHairSystem_registerCollisionSolverPreFrame(*args, **kwargs): pass
def MFnVolumeAxisField_swigregister(*args, **kwargs): pass
def MFnPfxGeometry_swigregister(*args, **kwargs): pass
def MHairSystem_getFollicle(*args, **kwargs): pass
def doublePtr_frompointer(*args, **kwargs): pass
def MFnParticleSystem_className(*args, **kwargs): pass
def boolPtr_swigregister(*args, **kwargs): pass
def MFnTurbulenceField_swigregister(*args, **kwargs): pass
def MRenderLine_className(*args, **kwargs): pass
def MDynamicsUtil_evalDynamics2dTexture(*args, **kwargs): pass
def MFnDragField_className(*args, **kwargs): pass
def MDynamicsUtil_removeNodeTypeFromRunup(*args, **kwargs): pass
def MnSolver_swigregister(*args, **kwargs): pass
def MFnUniformField_className(*args, **kwargs): pass
def MDynSweptLine_swigregister(*args, **kwargs): pass
def intPtr_frompointer(*args, **kwargs): pass
def MFnFluid_className(*args, **kwargs): pass
def MDynSweptTriangle_className(*args, **kwargs): pass
def shortPtr_swigregister(*args, **kwargs): pass
def MFnField_className(*args, **kwargs): pass
def MHairSystem_registerCollisionSolverCollide(*args, **kwargs): pass
def shortPtr_frompointer(*args, **kwargs): pass
def MHairSystem_getCollisionObject(*args, **kwargs): pass
def MFnRadialField_className(*args, **kwargs): pass
def MFnRadialField_swigregister(*args, **kwargs): pass
def _swig_setattr(self, class_type, name, value): pass


_newclass = 1


