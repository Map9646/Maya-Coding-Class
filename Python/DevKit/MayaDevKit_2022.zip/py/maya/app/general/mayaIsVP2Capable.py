if False:
    from typing import Dict, List, Tuple, Union, Optional

def mayaIsVP2Capable(): pass
def mayaVP2API(): pass
def mayaVP2APIIsOpenGLCoreProfile(): pass
def mayaVP2APIIsDirectX11(): pass
def mayaVP2APIIsOpenGL(): pass

