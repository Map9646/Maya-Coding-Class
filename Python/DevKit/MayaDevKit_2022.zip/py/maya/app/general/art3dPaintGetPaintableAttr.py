if False:
    from typing import Dict, List, Tuple, Union, Optional

def attributeToPaint_melToUI(value): pass
def attributeToPaint_uiToMel(value): pass
def art3dPaintGetPaintableAttr(allowCustomAttrs='True'):
    """
    Return list of all the names of 
    all color attrs common (to all selected shader) paintable attributes.
    This includes custom attributes.
    """
    pass


_dict_attributeToPaint_uiToMel = {}

_dict_attributeToPaint_melToUI = {}

k = 'transparency'

v = []


