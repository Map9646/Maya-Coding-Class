if False:
    from typing import Dict, List, Tuple, Union, Optional

def removePublishedAttrsFromContainer(obj, inAttrs): pass
def collectTripleAttrs(obj, attrs):
    """
    # Take a list of attrs and convert any contained triple children into
    # their parent. For example if the input is:
    #   diffuse, colorR, colorG, colorB
    # the return would be:
    #   diffuse, color
    """
    pass
def publishAttrToContainer(): pass
def pyError(errorString):
    """
    print an error message
    """
    pass
def unpublishAttrFromContainer(): pass
def addAndConnectObjAttrsToContainer(obj, inAttrs): pass

