if False:
    from typing import Dict, List, Tuple, Union, Optional

def reset(): pass


dataManager = None

scheduledEdits = []

db = {}

ttfCategories = {}


