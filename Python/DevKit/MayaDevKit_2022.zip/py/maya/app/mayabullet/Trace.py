if False:
    from typing import Dict, List, Tuple, Union, Optional

def Trace(tag="''"): pass
def TracePrint(strMsg): pass


_traceEnabled = False

_traceIndent = 0


