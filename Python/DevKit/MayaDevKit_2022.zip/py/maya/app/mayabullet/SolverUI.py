"""
SolverUI - Module containing functions for managing the solver node
        related UI elements.
"""


from maya.app.mayabullet.Trace import Trace


if False:
    from typing import Dict, List, Tuple, Union, Optional

class AEDeleteControl:
    def __call__(*args, **kw): pass
    def __init__(*args, **kw): pass


class AEOptionsChanged:
    def __call__(*args, **kw): pass
    def __init__(*args, **kw): pass




def optionsFormCtrl(*args, **kw): pass
def attrName(attr): pass
def optionsExist(*args, **kw): pass
def optionsColumnCtrl(*args, **kw): pass
def AEOptions(*args, **kw): pass


solverDisplayOptionsMap = {}


