if False:
    from typing import Dict, List, Tuple, Union, Optional

resources = {}

identifier = 'maya.app.type.AEtypeTemplate'


