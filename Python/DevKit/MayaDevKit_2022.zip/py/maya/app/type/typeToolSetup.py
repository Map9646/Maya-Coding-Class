from PySide2.QtCore import Slot
from ntpath import expanduser


if False:
    from typing import Dict, List, Tuple, Union, Optional

def wrapInstance(*args, **kwargs): pass
def createTypeToolWithNode(typeTool, font='None', style='None', text='None', legacy='False'): pass
def unwrapInstance(*args, **kwargs): pass
def connectShellDeformer(typeMesh, typeTransform, typeExtruder, typeTool): pass
def addPolyRemeshNodeType(typeTransform, typeExtruder, typeTool, typeMesh): pass
def addUVNodeToType(typeMesh, typeExtruder): pass
def connectTypeAdjustDeformer(typeMesh, typeTransform, typeExtruder, typeTool): pass
def createTypeTool(font='None', style='None', text='None', legacy='False'): pass


IN_BATCH_MODE = False


