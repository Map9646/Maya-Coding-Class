from maya.app.renderSetup.views.renderSetupPreferences import addRenderSetupPreferences


if False:
    from typing import Dict, List, Tuple, Union, Optional

def initialize(mplugin): pass
def uninitialize(mplugin): pass


_initializeModules = []

commands = []


