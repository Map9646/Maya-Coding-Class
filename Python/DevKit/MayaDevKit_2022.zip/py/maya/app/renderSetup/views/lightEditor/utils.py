if False:
    from typing import Dict, List, Tuple, Union, Optional

def findSelectedNodeFromMaya(): pass
def findNodeFromMaya(nodeName): pass
def createDynamicAttribute(nodeName, attrName, attrType, value): pass

