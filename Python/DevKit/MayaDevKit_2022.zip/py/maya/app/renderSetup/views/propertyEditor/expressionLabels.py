from PySide2.QtWidgets import QMenu
from PySide2.QtCore import Signal
from PySide2.QtWidgets import QLabel
from PySide2.QtCore import Qt


if False:
    from typing import Dict, List, Tuple, Union, Optional

class ExcludeExpressionLabel(QLabel):
    """
    This class represents an exclude expression label which has a right click menu used to create additional exclude expressions.
    """
    
    
    
    def __init__(self, text): pass
    def addExcludeExpression(self): pass
    def createStandardContextMenu(self, position):
        """
        Creates the right-click menu for creating additional exclude expressions.
        """
        pass
    excludeExpressionAdded = None
    
    
    staticMetaObject = None


class IncludeExpressionLabel(QLabel):
    """
    This class represents an include expression label which has a right click menu used to create additional include expressions.
    """
    
    
    
    def __init__(self, text): pass
    def addIncludeExpression(self): pass
    def createStandardContextMenu(self, position):
        """
        Creates the right-click menu for creating additional include expressions.
        """
        pass
    includeExpressionAdded = None
    
    
    staticMetaObject = None



