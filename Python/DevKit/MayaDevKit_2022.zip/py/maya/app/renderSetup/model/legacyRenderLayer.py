if False:
    from typing import Dict, List, Tuple, Union, Optional

def rename(oldLegacyRenderLayerName, newParentName): pass
def renderSetupLayer(legacyRenderLayerName): pass
def removeNodes(legacyRenderLayerName): pass
def create(parentName): pass
def appendNodes(legacyRenderLayerName, nodeNames): pass
def setRenderable(legacyRenderLayerName, value): pass
def makeVisible(legacyRenderLayerName): pass
def isVisible(legacyRenderLayerName): pass
def delete(legacyRenderLayerName): pass
def isRenderable(legacyRenderLayerName): pass

