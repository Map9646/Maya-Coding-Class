if False:
    from typing import Dict, List, Tuple, Union, Optional

class ClipboardData(object):
    def __init__(self, typeName, parentTypeName): pass
    def typeName(self): pass
    @property
    def parentTypeName(self): pass
    __dict__ = None
    
    
    __weakref__ = None




def getClipboardDataFromJson(clipBoardJson): pass


PARENT_TYPE_NAME = 'parentTypeName'


