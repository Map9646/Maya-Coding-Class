from maya.app.renderSetup.model.connectionOverride import ApplyConnectionOverride


if False:
    from typing import Dict, List, Tuple, Union, Optional

def postConstructor(layer): pass
def deleteApplyOverrideChain(last):
    """
    Delete a chain of apply override nodes.
    
    The argument is the last apply override node in the chain.
    """
    pass

