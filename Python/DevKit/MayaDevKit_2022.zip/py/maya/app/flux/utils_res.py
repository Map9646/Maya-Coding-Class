if False:
    from typing import Dict, List, Tuple, Union, Optional

value = []

resources = {}

identifier = 'maya.app.flux.utils'

key = 'kSelectSVG'


