if False:
    from typing import Dict, List, Tuple, Union, Optional

def loadTemplate(nodeType, nodeName): pass
def registerInstance(obj): pass
def onCreate(key): pass
def getAEEventFuncs(): pass
def onReplace(key): pass
def wrapAETemplate(nodeType): pass
def deregisterInstance(obj): pass
def registerMelProcWithStringArg(procName, funcName): pass

